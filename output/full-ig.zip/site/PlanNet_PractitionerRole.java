package http://hl7.org/fhir/us/davinci-pdex-plan-net/ImplementationGuide/hl7.fhir.us.davinci-pdex-plan-net-0.1.0;

import org.hl7.fhir.r5.model.ProfilingWrapper;

public class PlanNet_PractitionerRole {

}
