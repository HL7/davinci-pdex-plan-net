package http://hl7.org/fhir/us/davinci-pdex/ImplementationGuide/pdex-plan-net;

import org.hl7.fhir.r5.model.ProfilingWrapper;

public class PDexPlanPractitioner {

}
